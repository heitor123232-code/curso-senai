function greetings() {
    nome = document.getElementById("nome").value

    if (nome.trim() === "") {
        document.getElementById("mensagem").innerText = "Por favor insira seu nome"
    } else {
        hora = new Date().getHours()

    mensagem = ""

    if (hora < 12) {
        mensagem = ` Bom dia! ${nome} bem vindo ao mundo da programação!`
    } else if (hora < 18) {
         mensagem = ` Boa tarde! ${nome} bem vindo ao mundo da programação!`
    } else
    {
        mensagem = ` Boa noite! ${nome} bem vindo ao mundo da programação!`
    }

    document.getElementById("mensagem").innerText = mensagem
    }   
}   