const readline = require("readline");
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const numeroSecreto = Math.floor(Math.random() * 10) + 1; // de 1 a 10
let tentativas = 3

function perguntar() {
    if (tentativas > 0) {
        rl.question (`Digite um número entre 1 e 10 (tentativas restantes: ${tentativas}):`, (resposta) => {
            let chute = parseInt(resposta);

            if (chute === numeroSecreto) {
                console.log(" 😁 parabens! Você acertou o número segreto!");
                rl.close();
            } else {
                tentativas--;
                if (tentativas === 0) {
                    console.log(` 😞 fim de jogo! o numero secreto era ${numeroSecreto}.`);
                    rl.close();
                } else {
                    if (chute < numeroSecreto) {
                        console.log(" ☝️ dica: o numero secreto e MAIOR.");
                    } else {
                        console.log(" 👇 dica: o número secreto e MENOR.");
                    }
                    perguntar(); // chama de nova (while implícite)
                }
            }
        });
    }
}

perguntar();